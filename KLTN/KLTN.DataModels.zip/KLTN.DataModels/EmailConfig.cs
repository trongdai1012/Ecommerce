﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KLTN.DataModels
{
    public static class EmailConfig
    {
        public static string NameMailSend = "ecomercesendmail@gmail.com";
        public static string MailSend = "ecomercesendmail@gmail.com";
        public static string PasswordMailSend = "matkhau123";
        public static string MailReceive = "ecomercereceivemail@gmail.com";
        public static string NameMailReceive = "ecomercereceivemail@gmail.com";
    }
}
