﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KLTN.DataModels.Models.Users
{
    public class UserConfirmViewModel
    {
        public int Id { get; set; }
        public string confirmString { get; set; }
    }
}
