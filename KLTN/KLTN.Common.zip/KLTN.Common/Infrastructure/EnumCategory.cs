﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KLTN.Common.Infrastructure
{
    public enum EnumCategory
    {
        Laptop = 1,
        Mobile,
        Orther
    }
}
