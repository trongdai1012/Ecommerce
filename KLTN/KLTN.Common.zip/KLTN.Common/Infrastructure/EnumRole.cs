﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KLTN.Common.Infrastructure
{
    public enum EnumRole
    {
        Admin = 0,
        Mod,
        Clerk,
        WareHouseStaff,
        Deliver,
        Customer
    }
}
